jQuery(document).ready(function($){
    // Tooltips
    var tiptip_args = {
        'attribute' : 'data-tip',
        'fadeIn' : 50,
        'fadeOut' : 50,
        'delay' : 200
    };
    $(".icon-question-sign").tipTip( tiptip_args );
});

